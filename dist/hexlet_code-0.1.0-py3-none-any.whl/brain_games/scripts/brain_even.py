#!/usr/bin/env python
from brain_games.logic import run
from brain_games import even_check


def main():
   run(even_check)


if __name__ == '__main__':
    main()
